package swimworkoutbuilder.model.enums;

/**
 * CourseUnit = Pool length unit of measure
 */
public enum CourseUnit {
    YARDS,
    METERS
}
